demographics-test
==============
<b>Frontend</b>
<p> I have tested application with Chrome and Firefox.</p>
<p>
The frontend has been developed with Angular. Detailed info: <br/>
Angular CLI: 11.0.5 <br/>
Node: 14.15.3<br/>
OS: win32 x64<br/>

Angular: 11.0.5<br/>
typescript  4.0.5<br/>
<p>
<b>Backend</b>
<p> Backend has been developed with Springboot and Java. Gradle has been used for build. Jdk version was 1.8. </p>
<br/>
<b>Run and Verify</b><br/>
1. Extract demographics.zip<br>
2. Run the jar file inside the extracted folder with "java -jar demographics-0.0.1-SNAPSHOT.jar"<br/>
3. Check that application is running by writing this in the your browser http://localhost:8080/demographics?city=Stockholm<br/>
4. Browse to https://govanm.github.io

Some thoughts about the test
------------------------------------------
1. It was not clear for me where I have to obtain the list of cities. I couldn't find any api call in Weatherstack api for fetching the list of supported cities. <br/>
   I downloaded a list of all cities in the world with about 400000 entries and more info and I used som regular expressions to remove unnecessary information and reduce the file size.<br/>
   Unfortunately the list contains some duplicates and because of this you will see some duplicates (Don't try 'Hamburg') . <br/>
2. I downloaded and used weather icons from http://www.alessioatzeni.com/meteocons/ and I have tried to map the weather code from Weatherstack to the right icon. I have missed some of them, and it happens that some weather info has no icon.<br/>
   You are going to probably see some of this. By the way Why we couldn't use the weather icons from Weatherstack? Was there a reason except that they are ugly?  
3. Weatherstack api contains much wrong information (Not recommended for production use). e.g. Södertälje is a part of Suecia country, Västerås is in Suède while Solna is in Sweden.  <br/>
   If you are searching for "K'alak'i T'bilisi" you are going to find information about "Nap'areuli". Obviously I didn't try to fix these errors. You can see some of this in the attached image.<br/>
4. The implementation lacks serious errorhandling like explicit mapping for /error in backend or a field to show the error to users in the frontend.<br>
   It is possible to see the error in browser console but inside application if you are typing something wrong and try to fetch weather information nothing will happen.
